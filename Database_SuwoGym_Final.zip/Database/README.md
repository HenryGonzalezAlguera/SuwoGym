﻿# Base de datos SUWÓ Gym

Esta carpeta contiene todo lo necesario para crear la base de datos desde cero.

## Archivos

1. `01_SuwoGym_Estructura.sql`
   - Crea la base de datos `SuwoGym`.
   - Crea las tablas.
   - Crea llaves primarias y foráneas.
   - Crea restricciones e índices.
   - Crea los procedimientos almacenados.

2. `02_SuwoGym_DatosIniciales.sql`
   - Inserta los roles:
     - Administrador
     - Entrenador
     - Miembro
   - Inserta las clases:
     - Funcionales
     - CrossFit
     - Baile
   - Inserta los planes:
     - Mensual
     - Trimestral
     - Anual

3. `03_SuwoGym_AdministradorDemo.sql`
   - Crea el primer usuario administrador para iniciar sesión.

## Orden de ejecución en SQL Server Management Studio

Ejecute los archivos exactamente en este orden:

1. `01_SuwoGym_Estructura.sql`
2. `02_SuwoGym_DatosIniciales.sql`
3. `03_SuwoGym_AdministradorDemo.sql`

Cada archivo debe ejecutarse completo con el botón **Ejecutar** o con la tecla **F5**.

## Credenciales del administrador demo

Correo:

`admin@suwo.local`

Contraseña:

`SuwoAdmin2026!`

## Configuración de la API

Después de crear la base, revise la cadena de conexión de:

`SuwoGym_API/appsettings.json`

La base debe apuntar a:

`Initial Catalog=SuwoGym`

También debe utilizar el nombre correcto de la instancia de SQL Server de cada computadora.

## Verificación rápida

Después de ejecutar los tres scripts, puede comprobar la instalación con:

```sql
USE [SuwoGym]
GO

SELECT COUNT(*) AS TotalTablas
FROM sys.tables;
GO

SELECT COUNT(*) AS TotalProcedimientos
FROM sys.procedures;
GO

SELECT *
FROM dbo.Rol;
GO

SELECT *
FROM dbo.Clase;
GO

SELECT *
FROM dbo.PlanMembresia;
GO

SELECT
    IdUsuario,
    IdRol,
    Nombre,
    Apellido,
    CorreoElectronico,
    Estado
FROM dbo.Usuario;
GO
```

Resultado esperado aproximado:

- 15 tablas.
- 63 procedimientos almacenados.
- 3 roles.
- 3 clases.
- 3 planes.
- 1 administrador demo.

## Archivos que no deben subirse a GitHub

- Archivos `.bak`.
- Archivos `.mdf`.
- Archivos `.ldf`.
- Credenciales reales.
- Contraseñas de aplicación.
- Claves JWT reales.
- Datos personales de usuarios.
