﻿USE [SuwoGym]
GO

SET NOCOUNT ON;
GO

/* ============================================================
   SUWÓ GYM - USUARIO ADMINISTRADOR DEMO

   Credenciales de prueba:
   Correo: admin@suwo.local
   Contraseña: SuwoAdmin2026!

   Este usuario es únicamente para desarrollo y demostración.
   ============================================================ */

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.Rol
    WHERE IdRol = 1
      AND NombreRol = N'Administrador'
)
BEGIN
    RAISERROR(
        'Primero debe ejecutar 02_SuwoGym_DatosIniciales.sql.',
        16,
        1
    );
    RETURN;
END
GO

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.Usuario
    WHERE CorreoElectronico = N'admin@suwo.local'
)
BEGIN
    INSERT INTO dbo.Usuario
    (
        IdRol,
        Nombre,
        Apellido,
        CorreoElectronico,
        Identificacion,
        Telefono,
        FechaNacimiento,
        Direccion,
        ContrasennaHash,
        DebeCambiarContrasenna,
        Estado,
        FechaRegistro,
        FechaUltimoAcceso
    )
    VALUES
    (
        1,
        N'Administrador',
        N'Demo',
        N'admin@suwo.local',
        N'ADMIN-DEMO-001',
        NULL,
        NULL,
        NULL,
        N'$2b$12$mm5Q28sYDVogabM/zTB.CONSia/ZVOXrxeUuENqE2Zaw66PB5LNhm',
        0,
        1,
        SYSDATETIME(),
        NULL
    );

    PRINT N'Usuario administrador demo creado correctamente.';
END
ELSE
BEGIN
    PRINT N'El usuario administrador demo ya existe.';
END
GO
